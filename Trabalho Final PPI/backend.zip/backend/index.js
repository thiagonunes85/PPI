const express = require('express');
const path = require('path');
const mysql = require('mysql2')
const cors = require('cors');

const connection = mysql.createConnection({
  host: 'localhost',
  user: 'sacd',
  password: 'sacd#2021',
  database: 'poo'
})
connection.connect()
connection.query('SELECT CURRENT_TIMESTAMP()', (err, rows, fields) => {
  if (err) throw err
  console.log('The solution is: ', rows[0].solution)
})
//connection.end()

// criando o objeto express
const app = express();
app.use(cors());
app.use("/",express.static(path.join(__dirname,'client')))
// rota get
app.get("/api",(req, res)=>{
  
  //res.set("Content-Type","text/plain");
  res.type("json");
  res.send('{"msg":"Hello World from GET"}');
})
//

app.get('/sistema',  (req, res)=> {
    connection.connect()
    connection.query("SELECT * FROM tb00_sistema", function (err, rows,fields)
    {
    if (err) throw err;
            if (!err && rows.length > 0) {
                res.json(rows);
            } else {
                res.json([]);
            }
        });
        //connection.end()
    });



const PORT = 5000;
// 
app.listen(PORT, ()=>{
  console.log(`Server rodando na porta ${PORT}`);
});

